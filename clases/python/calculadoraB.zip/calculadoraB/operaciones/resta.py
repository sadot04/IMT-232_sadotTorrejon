def restar(a,b):
    return a - b