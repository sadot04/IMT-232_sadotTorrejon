def multiplicar (a, b):
    return a * b