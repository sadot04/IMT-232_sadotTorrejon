#ifndef FUNCIONES_H
#define FUNCIONES_H

int esPrimo(int num);
int factorial(int num);
int contarDigitos(int num);
int multiplosDeTres(int num);

#endif