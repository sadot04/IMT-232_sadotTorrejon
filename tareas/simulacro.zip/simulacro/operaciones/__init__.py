from .operacion1 import funcion1
from .operacion2 import piramide
from .operacion3 import serieAlernada
from .operacion4 import imprimirCuantosPrimos
from .operacion5 import esPalindromo